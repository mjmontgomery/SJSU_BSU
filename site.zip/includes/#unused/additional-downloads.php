<div class="text">
				<table width="407" cellpadding="0" cellspacing="0" id="assignments">
					<tr>
						<th width="270" class="assignment"> Title</th>
						<th width="135">Download</th>
					</tr>
                    <tr>
						<td class="assignment">Diversity Assignment Data Chart pt. 1</td>
						<td><a href="files/downloads/diversity_data_chart.xls">.xls</a> | <a href="files/downloads/diversity_data_chart.pdf">PDF</a></td>
					</tr>
                    <tr>
						<td class="assignment">Diversity Assignment Data Chart pt. 2</td>
						<td><a href="files/downloads/diversity_data_chart_coping.xls">.xls</a> | <a href="files/downloads/diversity_data_chart_coping.pdf">PDF</a></td>
					</tr>
                    <tr>
						<td class="assignment">Diversity Assignment Example Data Chart</td>
						<td><a href="files/downloads/diversity_example_data_chart.xls">.xls</a> | <a href="files/downloads/diversity_example_data_chart.pdf">PDF</a></td>
					</tr>
                   
                    <tr>
						<td class="assignment">Annotated Bib Rubric </td>
						<td><a href="files/downloads/annotated_bib_rubric _f13.docx">.docx</a> | <a href="files/downloads/annotated_bib_rubric _f13.pdf">PDF</a></td>
					</tr>
                    <tr>
						<td class="assignment">Pathways Planner</td>
						<td><a href="files/downloads/pathways_planner.xlsx">.xlsx</a> | <a href="files/downloads/pathways_planner.pdf">PDF</a></td>
					</tr>
					<tr>
						<td class="assignment">Pathways Supplemental Sheet</td>
						<td><a href="files/downloads/pathways_supplemental.xlsx">.xlsx</a> | <a href="files/downloads/pathways_supplemental.pdf">PDF</a></td>
					</tr>
                    <tr>
						<td class="assignment">Presidential Directive</td>
						<td><a href="files/downloads/pres_directive.ppt">.ppt</a> | <a href="files/downloads/Pres_directive.pdf">PDF</a></td>
					</tr>
                    <tr>
						<td class="assignment">Online Resources Outline</td>
						<td><a href="files/downloads/online_resources.docx">.docx</a> | <a href="files/downloads/online_resources.pdf">PDF</a></td>
					</tr>
					<!--<tr>
						<td class="assignment">There are no current downloads</td>
						<td>---</td>
					</tr>
					<tr>
						<td class="assignment">Transfer Orientation PowerPoint</td>
						<td><a href="files/downloads/transfer-orientation.ppt">.ppt</a> | <a href="files/downloads/transfer-orientation.pdf">PDF</a></td>
					</tr> -->
					<!--<tr>
						<td class="assignment">Major GPA Calculator</td>
						<td><a href="major_gpa.php">Link</a></td>
					</tr> -->
					<tr>
						<td class="assignment">GPA Calculator</td>
						<td><a href="gpa.php">Link</a></td>
					</tr>
                    <tr>
						<td class="assignment">Grad School PowerPoint</td>
						<td><a href="files/downloads/grad_school.pptx">.pptx</a> | <a href="files/downloads/grad_school.pdf">PDF</a></td>
					</tr>
                    <tr>
						<td class="assignment">Grad School Pamphlet</td>
						<td><a href="files/downloads/grad_school_pamphlet.pdf">.PDF</a></td>
					</tr>
					<!--<tr>
						<td class="assignment">General Education Checklist</td>
						<td><a href="files/downloads/ge_checklist.xls">.xls</a> | <a href="files/downloads/ge_checklist.pdf">PDF</a></td>
					</tr>
					<tr>
						<td class="assignment">Grade Check</td>
						<td><a href="files/downloads/grade_check.xls">.xls</a> | <a href="files/downloads/grade_check.pdf">PDF</a></td>
					<tr>
						<td class="assignment">Faculty, Services and Office Hours Worksheet</td>
						<td><a href="files/downloads/fso_worksheet.xls">.xls</a> | <a href="files/downloads/fso_worksheet.pdf">PDF</a></td>
					</tr>
					<tr>
						<td class="assignment">Learning Styles PowerPoint</td>
						<td><a href="files/downloads/learning_styles.ppt">.ppt</a> | <a href="files/downloads/learning_styles.pdf">PDF</a></td>
					</tr>
					<tr>
						<td class="assignment">What is happening to the CSU? PowerPoint</td>
						<td><a href="files/downloads/what_is_happening.ppt">.ppt</a> | <a href="files/downloads/what_is_happening.pdf">PDF</a></td>
					</tr>
					<tr>
						<td class="assignment">Assignments Info (Photo Journal, Learning Styles and Campus Events)</td>
						<td><a href="files/downloads/assignment_info.pdf">PDF</a></td>
					</tr>
					<tr>
						<td class="assignment">Time Management Toolkit</td>
						<td><a href="video/time.php">Video Link</a> | <a href="files/downloads/time.xls">.xls</a> | <a href="files/downloads/time.pdf">PDF</a></td>
					</tr>
					<tr>
						<td class="assignment">Student Information Sheet</td>
						<td><a href="files/downloads/student_info_sheet.doc">.doc</a> | <a href="files/downloads/student_info_sheet.pdf">PDF</a></td>
					</tr>
					<tr>
						<td class="assignment">Goals and Objectives PowerPoint</td>
						<td><a href="files/downloads/goals_and_objectives.ppt">.ppt</a> | <a href="files/downloads/goals_and_objectives.pdf">PDF</a></td>
					</tr> -->
				</table>
			</div>