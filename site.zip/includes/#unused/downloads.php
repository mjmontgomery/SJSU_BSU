<div class="top">Downloads</div>
			<div class="text">
				<ul>
                	<li class="bold">Science 90 Fall 2014 Greensheet</li>
					<li class="link">> <a href="files/downloads/90_fall_2014_greensheet.PDF">PDF</a></li>
                
                
                <!--
					<li class="bold">There are no recently added downloads to the Science 90 site.</li>
                    <li class="bold">Time Management</li>
					<li class="link">> <a href="files/downloads/time_management.xls">.xls</a></li>
                    <li class="bold">Spring 2014 Greensheet</li>
					<li class="link">> <a href="files/downloads/90t_spring_2014_greensheet.docx">.docx</a> | <a href="files/downloads/90t_spring_2014_greensheet.PDF">PDF</a></li>
                    <li class="bold">Pathways Planner</li>
					<li class="link">> <a href="files/downloads/pathways_planner.xlsx">.xlsx</a> | <a href="files/downloads/pathways_planner.pdf">PDF</a></li>
                    
                    <li class="bold">Grade Check</li>
					<li class="link">> <a href="files/downloads/grade_check.xls">.xls</a> | <a href="files/downloads/grade_check.pdf">PDF</a></li>
                    
					<li class="bold">Faculty, Services and Office Hours Worksheet</li>
					<li class="link">> <a href="files/downloads/fso_worksheet.xlsx">.xlsx</a> | <a href="files/downloads/fso_worksheet.pdf">PDF</a></li>

                    <li class="link"><a href="assignments.php">> Get Full List of Assignments</a></li> -->
				</ul>
			</div>