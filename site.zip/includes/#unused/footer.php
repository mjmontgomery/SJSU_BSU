<div id="yellow-space">
	<div id="foot-wrap">
		<div id="footer"><?php echo $short; ?> | San Jose State University &copy; 2013-2014 | <a href="mailto:mason.itkin@sjsu.edu">Contact Webmaster</a></div>
	</div>
</div>