<?php
	$major = $_POST['major'];
	if ($major == "default") {
		header ("Location: ../majorgpa.php");
	}
	
	if ($major == "ae") {
		header ("Location: ../majorgpa.php?major=ae&global=");
	}
	
	if ($major == "aviation") {
		header ("Location: ../majorgpa.php?major=aviation&global=");
	}
	
	if ($major == "cheme") {
		header ("Location: ../majorgpa.php?major=cheme&global=");
	}
	
	if ($major == "ce") {
		header ("Location: ../majorgpa.php?major=ce&global=");
	}
	
	if ($major == "compe") {
		header ("Location: ../majorgpa.php?major=compe&global=");
	}
	
	if ($major == "ee") {
		header ("Location: ../majorgpa.php?major=ee&global=");
	}
	
	if ($major == "ge") {
		header ("Location: ../majorgpa.php?major=ge&global=");
	}
	
	if ($major == "ise") {
		header ("Location: ../majorgpa.php?major=ise&global=");
	}
	
	if ($major == "indtech") {
		header ("Location: ../majorgpa.php?major=indtech&global=");
	}
	
	if ($major == "mate") {
		header ("Location: ../majorgpa.php?major=mate&global=");
	}
	
	if ($major == "me") {
		header ("Location: ../majorgpa.php?major=me&global=36");
	}
	
	if ($major == "se") {
		header ("Location: ../majorgpa.php?major=se&global=");
	}
?>