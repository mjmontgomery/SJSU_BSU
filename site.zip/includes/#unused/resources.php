<div id="content">
	<div id="a" class="title">A</div>
	<div class="text">
		<ul>
			<li>> <a href="http://www.sjsu.edu/registrar/services/students/ab540.html">AB 540 (Definitions and explanations)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/soc-fall/rec-5.html">Academic Deans and Program Administrators</a></li>
			<li>> <a href="http://www.sjsu.edu/ugs/students/advising/">Academic Advising Centers</a></li>
			<li>> <a href="https://www.nmnathletics.com/ViewArticle.dbml?DB_OEM_ID=5600&KEY=&ATCLID=201503&SPID=2807&SPSID=35588">Academic Advising - Athletics</a></li>
			<li>> <a href="http://www.cob.sjsu.edu/bsac/">Academic Advising - College of Business</a></li>
			<li>> <a href="http://www.engr.sjsu.edu/students/essc/advising/">Academic Advising - College of Engineering</a></li>
			<li>> <a href="http://www.science.sjsu.edu/cosac/">Academic Advising - College of Science</a></li>
			<li>> <a href="http://www.sjsu.edu/aars/">Academic Advising - General Education</a></li>
			<li>> <a href="http://www.sjsu.edu/academic_programs/calendars/academic_calendar/">Academic Calendar</a></li>
			<li>> <a href="http://www.sjsu.edu/senate/S04-12.pdf">Academic Integrity</a></li>
			<li>> <a href="http://www.science.sjsu.edu/transfer/f10/handouts/Ed_Planner.xls">Academic Planner</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/catalog/rec-1942.html">Academic Probation (definition)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/catalog/rec-1934.html">Academic Disqualification (definition)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/catalog/scholastic.html">Academic Probation and Disqualification (undergrad)</a></li>
			<li>> <a href="http://www.sjsu.edu/ugs/docs/petitions/New_AR_Disregard_Aug_09.pdf">Academic Renewal Petition</a></li>
			<li>> <a href="http://ies.sjsu.edu/ou/academic-information/academic-renewal">Academic Renewal Policy</a></li>
			<li>> <a href="http://www.sjsu.edu/senate/">Academic Senate web page</a></li>
			<li>> <a href="http://www.sjsu.edu/ugs/arb/section4f.html">Academic Standing</a></li>
			<li>> <a href="http://www.sjsu.edu/atn/">Academic Technology Network</a></li>
			<li>> <a href="http://www.sjsu.edu/sjsuone/about/">Accessing online wireless at SJSU</a></li>
			<li>> <a href="http://www.cob.sjsu.edu/acct&fin/">Accounting and Finance Department</a></li>
			<li>> <a href="http://www.acerail.com/">ACE (Altamont Commuter Express Train)</a></li>
			<li>> <a href="http://artic.sjsu.edu/static/catalog/cbe.html">ACT-PEP (Proficiency Exam Program) What counts for what &hellip;</a></li>
			<li>> <a href="http://www.adacompliance.sjsu.edu/index.htm">ADA Compliance Office</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/calendar/2092/index.htm">Add Deadline</a></li>
			<li>> <a href="http://slisweb.sjsu.edu/enrollment/lateadd.htm">Adding Courses</a></li>
			<li>> <a href="http://www.ajbureau.sjsu.edu/">Administration of Justice Bureau Department</a></li>
			<li>> <a href="http://www.csumentor.edu/">Admissions Application</a></li>
			<li>> <a href="http://www.sjsu.edu/visit/preadmission/">Admissions Counseling</a></li>
			<li>> <a href="http://www.sjsu.edu/gradstudies/Prospective/Graduate_Programs.html">Admissions deadlines for Grad. Programs (SJSU)</a></li>
			<li>> <a href="http://www.sjsu.edu/visit/admissionrequirements/">Admission Requirements</a></li>
			<li>> <a href="http://info.sjsu.edu/home/admission.html">Admissions, Students</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/soc-fall/sjstudies.html">Advanced GE (General Education - SJSU Studies requirements)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/catalog/ap.html">Advanced Placement Tests and Scores</a></li>
			<li>> <a href="https://www.nmnathletics.com/ViewArticle.dbml?DB_OEM_ID=5600&KEY=&ATCLID=201503&SPID=2807&SPSID=35588">Advising - Athletics</a></li>
			<li>> <a href="http://www.cob.sjsu.edu/bsac/">Advising - College of Business</a></li>
			<li>> <a href="http://www.engr.sjsu.edu/students/essc/advising/">Advising - College of Engineering</a></li>
			<li>> <a href="http://www.science.sjsu.edu/cosac/">Advising - College of Science</a></li>
			<li>> <a href="http://www.sjsu.edu/aars/">Advising - General Education</a></li>
			<li>> <a href="http://www.sjsu.edu/advising/">Advising HUB</a></li>
			<li>> <a href="http://www.sjsu.edu/depts/AFROTC/homepage.html">Aerospace Studies (Air Force ROTC) Department</a></li>
			<li>> <a href="http://www.sjsu.edu/afam/">African American Studies Department</a></li>
			<li>> <a href="http://www.sjsu.edu/studenthealth/clinical_services/">AIDs/HIV (info, testing &amp; counseling)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/soc-fall/ge.html">American Institutions (Area F 1-2-3)</a></li>
			<li>> <a href="http://www.sjsu.edu/studenthealth/clinical_services/">Allergy consultation</a></li>
			<li>> <a href="http://www.science.sjsu.edu/amp/">Alliance for Minority Participation (AMP)</a></li>
			<li>> <a href="http://www.acerail.com/">Altamont Commuter Express Train (ACE)</a></li>
			<li>> <a href="http://www.adacompliance.sjsu.edu/index.htm">Americans with Disabilities Act (ADA) Compliance Office</a></li>
			<li>> <a href="http://www.science.sjsu.edu/amp/">AMP (Alliance for Minority Participation)</a></li>
			<li>> <a href="http://www.amtrak.com/servlet/ContentServer?pagename=Amtrak/HomePage">Amtrak Train</a></li>
			<li>> <a href="http://www.sjsupd.com/asr/index.html">Annual safety report</a></li>
			<li>> <a href="http://www.sjsu.edu/depts/anthropology/">Anthropology Department</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/services/visitor_concurrent/">Application to Visit another CSU</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/catalog/ap.html">AP test and scores (tests and scores that equal college credit)</a></li>
			<li>> <a href="http://www.sjsu.edu/gradstudies/Prospective/How_To_Apply.html">Application Deadline for Graduate Admissions application</a></li>
			<li>> <a href="http://www.sjsu.edu/future_students_families/">Application Deadline for Undergraduate Admissions application</a></li>
			<li>> <a href="http://www.sjsu.edu/casa/">Applied Sciences and Arts, College of</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/docs/grad_app.pdf">Applying for Graduation</a></li>
			<li>> <a href="http://www.union.sjsu.edu/Aquatic_Center/aquatic_center.html#maincontent">Aquatic Center</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/soc-spring/sjstudies.html">Areas R, S, V, and Z</a></li>
			<li>> <a href="http://ad.sjsu.edu/">Art and Design Department</a></li>
			<li>> <a href="http://transfer.sjsu.edu/">Articulation office and web page</a></li>
			<li>> <a href="http://www.assist.org/web-assist/welcome.html">Articulation and Transferable courses (using ASSIST)</a></li>
			<li>> <a href="http://www.sjsu.edu/aspire/">ASPIRE</a></li>
			<li>> <a href="http://as.sjsu.edu/asps/">AS Print Shop</a></li>
			<li>> <a href="http://www.assist.org/web-assist/welcome.html">ASSIST (Articulation System Stimulating Interinstitutional Student Transfer)</a></li>
			<li>> <a href="http://as.sjsu.edu/">Associated Students</a></li>
			<li>> <a href="http://www.physics.sjsu.edu/">Astronomy Dept.</a></li>
			<li>> <a href="http://www.sjsuspartans.com/ViewArticle.dbml?DB_OEM_ID=5600&ATCLID=1505952">Athletics</a></li>
			<li>> <a href="http://www.sjsuspartans.com/main/Schedule.dbml">Athletic Schedule</a></li>
			<li>> <a href="http://www.sjsu.edu/parking/pages/motorist2.html">Automobile trouble</a></li>
			<li>> <a href="http://www.engr.sjsu.edu/avtech/">Aviation Program</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="b" class="title">B</div>
	<div class="text">
		<ul>
			<li>> <a href="http://as.sjsu.edu/ascdc/index.jsp?val=ascdc_admin_fees">Baby Sitting Services</a></li>
			<li>> <a href="http://as.sjsu.edu/ashouse/index.jsp?val=bbqandrecreation">Barbecue Pits</a></li>
			<li>> <a href="http://as.sjsu.edu/asts/index.jsp?val=sjsu_bicycles">Bicycles on Campus</a></li>
			<li>> <a href="http://www.biology.sjsu.edu/">Biology Dept.</a></li>
			<li>> <a href="http://www.biology.sjsu.edu/news/news.aspx">Biology Dept. Events</a></li>
			<li>> <a href="http://www.sjsu.edu/studenthealth/health_education/sexual_health/">Birth Control</a></li>
			<li>> <a href="http://online.sjsu.edu/">BlackBoard</a></li>
			<li>> <a href="http://as.sjsu.edu/asgsc/index.jsp?val=gsc_book">Book Loan program (for students)</a></li>
			<li>> <a href="http://www.amazon.com/books/">Book Store (Amazon)</a></li>
			<li>> <a href="http://www.abebooks.com/">Book Store (Abe Books)</a></li>
			<li>> <a href="http://books.half.ebay.com/">Book Store (Half)</a></li>
			<li>> <a href="http://www.spartanbookstore.com/home.aspx">Book Store (on campus)</a></li>
			<li>> <a href="http://www.robertsbookstore.com/">Book Store (Robert&#39;s)</a></li>
			<li>> <a href="http://www.union.sjsu.edu/su/Bowling_Center/bowling_center.html#maincontent">Bowling Center</a></li>
			<li>> <a href="http://www.sjsu.edu/atn/delivery/webcasting/">Broadcasting classes via the web</a></li>
			<li>> <a href="http://www.sjsu.edu/bursar/">Bursar's Office</a></li>
			<li>> <a href="http://www.vta.org/schedules/schedules_bynumber.html#102">Bus Schedule</a></li>
			<li>> <a href="http://www.cob.sjsu.edu/">Business, College of</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="c" class="title">C</div>
	<div class="text">
		<ul>
			<li>> <a href="http://www.csac.ca.gov/doc.asp?id=20">Cal Grant</a></li>
			<li>> <a href="gpa.php">Calculating GPA (Grade Point Average)</a></li>
			<li>> <a href="http://www.math.sjsu.edu/~calculus/">Calculus and Precalculus</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/calendar/">Calendar (Registration)</a></li>
			<li>> <a href="http://www.sjsu.edu/academic_programs/calendars/academic_calendar/">Calendar for Academic Year</a></li>
			<li>> <a href="http://www.caltrain.com/">Caltrain</a></li>
			<li>> <a href="http://www.math.sjsu.edu/camcos/">CAMCOS (Center for Applied Math, Computation, and Statistics)</a></li>
			<li>> <a href="http://www.apb.sjsu.edu/Data_&_Reporting/Statistical_Abstract.cfm">Campus Data</a></li>
			<li>> <a href="https://sjsuone.sjsu.edu/sjsuphonebook/">Campus Directory</a></li>
			<li>> <a href="http://www.sjsu.edu/about_sjsu/docs/SJSU_campus_map.pdf">Campus Map</a></li>
			<li>> <a href="http://www.sjsu.edu/studenthealth/clinical_services/pharmacy/index.htm">Campus Pharmacy</a></li>
			<li>> <a href="https://sjsuone.sjsu.edu/sjsuphonebook/">Campus Phone Book online</a></li>
			<li>> <a href="http://www.sjsu.edu/about_sjsu/facts_and_figures/">Campus Stats (general)</a></li>
			<li>> <a href="http://www.sjsu.edu/parking/pages/motorist2.html">Car Battery troubles</a></li>
			<li>> <a href="http://careercenter.sjsu.edu/">Career Center</a></li>
			<li>> <a href="http://careercenter.sjsu.edu/students/students.html">Career Planning (SJSU)</a></li>
			<li>> <a href="http://www.sjsu.edu/bursar/directory/cashier/index.htm">Cashier</a></li>
			<li>> <a href="http://info.sjsu.edu/home/catalog.html">Catalog SJSU</a></li>
			<li>> <a href="http://www.collegesource.org/">Catalogs (for other colleges &amp; universities)</a></li>
			<li>> <a href="http://www.math.sjsu.edu/camcos/">Center for Applied Math, Computation, and Statistics (CAMCOS)</a></li>
			<li>> <a href="http://www.sjsu.edu/ccll/">Center for Community Learning and Leadership</a></li>
			<li>> <a href="http://as.sjsu.edu/cccac/">Cesar E.Chavez Community Action Center (CCCAC)</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/docs/major_minor.pdf">Change of Major form</a></li>
			<li>> <a href="http://www.sjsu.edu/senate/f88-10.htm">Cheating Policy (Academic Dishonesty)</a></li>
			<li>> <a href="http://as.sjsu.edu/cheer/index.jsp?val=cheer_home">Cheerleading at SJSU</a></li>
			<li>> <a href="http://www.engr.sjsu.edu/cme/">Chemical and Materials Engineering Department</a></li>
			<li>> <a href="http://www.chemistry.sjsu.edu/">Chemistry Dept.</a></li>
			<li>> <a href="http://www.chemistry.sjsu.edu/index.php?q=node/38">Chemistry Dept. Events</a></li>
			<li>> <a href="http://www.sjsu.edu/chad/">Child and Adolescent Development (CHAD) Department</a></li>
			<li>> <a href="http://as.sjsu.edu/ascdc/index.jsp?val=ascdc_admin_fees">Child Care</a></li>
			<li>> <a href="http://www.engr.sjsu.edu/civil/">Civil and Environmental Engineering Department</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/soc-fall/soc-footnotes.html">Class Notes (code numbers in the schedule of classes)</a></li>
			<li>> <a href="http://info.sjsu.edu/cgi-bin/pdfserv?atok=soc">Class Schedules Archived from 2005</a></li>
			<li>> <a href="http://my.sjsu.edu/students/pdf_schedules/index.htm">Class Schedules PDF</a></li>
			<li>> <a href="http://info.sjsu.edu/home/schedules.html">Class Schedules WEB</a></li>
			<li>> <a href="http://www.sjsu.edu/senate/S77-6.pdf">CLEP (College Level Exam Program) scores what counts for what &hellip;</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/soc-fall/soc-footnotes.html">Code numbers next to classes in the sched of classes (Class Notes)</a></li>
			<li>> <a href="http://www.sjsu.edu/colleges_departments/">Colleges and Departments</a></li>
			<li>> <a href="http://www.collegesource.org/">College Catalogs (Online source of US Colleges &amp; Univeristy Catalogs)</a></li>
			<li>> <a href="http://www.sjsu.edu/casa/">College of Applied Sciences and Arts</a></li>
			<li>> <a href="http://www.cob.sjsu.edu/">College of Business</a></li>
			<li>> <a href="http://www1.coe.sjsu.edu/">College of Education</a></li>
			<li>> <a href="http://www.engr.sjsu.edu/">College of Engineering</a></li>
			<li>> <a href="http://www.sjsu.edu/humanities/">College of Humanities and the Arts</a></li>
			<li>> <a href="http://www.science.sjsu.edu/">College of Science</a></li>
			<li>> <a href="http://www.science.sjsu.edu/?q=event">College of Science Events</a></li>
			<li>> <a href="http://www.sjsu.edu/socialsciences/">College of Social Science</a></li>
			<li>> <a href="http://www.sjsu.edu/commencement/">Commencement Guide</a></li>
			<li>> <a href="http://www.sjsu.edu/comm/">Communication Studies Department</a></li>
			<li>> <a href="http://www.sjsu.edu/cds/">Communicative Disorders and Sciences Department</a></li>
			<li>> <a href="http://as.sjsu.edu/cccac/">Community Action Center</a></li>
			<li>> <a href="http://artic.sjsu.edu/web-dbgen/artic/all-course-to-course.html">Community College courses that transfer</a></li>
			<li>> <a href="http://artic.sjsu.edu/web-dbgen/artic/all-ge.html">Community College courses that transfer as GE Courses</a></li>
			<li>> <a href="http://artic.sjsu.edu/web-dbgen/artic/all-school-to-school.html">Community College courses that transfer as Major Courses</a></li>
			<li>> <a href="communitycolleges.php">Community College information (local)</a></li>
			<li>> <a href="http://www.sjsu.edu/ccll/">Community Learning and Leadership</a></li>
			<li>> <a href="http://www.engr.sjsu.edu/cmpe/">Computer Engineering Dept.</a></li>
			<li>> <a href="http://as.sjsu.edu/ascsc/index.jsp">Computer Lab (Associated Students)</a></li>
			<li>> <a href="http://as.sjsu.edu/ascsc/index.jsp?val=csc_repair">Computer repair (personal)</a></li>
			<li>> <a href="http://as.sjsu.edu/ascsc/index.jsp?val=csc_lrp">Computer rental (personal)</a></li>
			<li>> <a href="http://www.cs.sjsu.edu/">Computer Science Dept.</a></li>
			<li>> <a href="http://www.union.sjsu.edu/ec/Event_Center_Arena/event_center_arena.html">Concerts and events on campus (Event Center)</a></li>
			<li>> <a href="http://sa.sjsu.edu/ombudsman/index.html">Conflict resolution</a></li>
			<li>> <a href="http://www.sjsu.edu/studenthealth/health_education/sexual_health/">Contraception</a></li>
			<li>> <a href="http://as.sjsu.edu/asps/">Copy Shop (on campus)</a></li>
			<li>> <a href="http://www.sjsu.edu/ugs/docs/petitions/Intensive_Science.pdf">Core Intensive Science plan</a></li>
			<li>> <a href="http://www.science.sjsu.edu/cosac/">COSAC (College of Science Advising Center)</a></li>
			<li>> <a href="https://www.nmnathletics.com/ViewArticle.dbml?DB_OEM_ID=5600&KEY=&ATCLID=201503&SPID=2807&SPSID=35588">Counseling - Athletics</a></li>
			<li>> <a href="http://www.cob.sjsu.edu/bsac/">Counseling - College of Business</a></li>
			<li>> <a href="http://www.engr.sjsu.edu/students/essc/advising/">Counseling - College of Engineering</a></li>
			<li>> <a href="http://www.science.sjsu.edu/cosac/">Counseling - College of Science</a></li>
			<li>> <a href="http://www.sjsu.edu/aars/">Counseling - General Education</a></li>
			<li>> <a href="http://sa.sjsu.edu/counseling/index.html">Counseling Services</a></li>
			<li>> <a href="http://www.sjsu.edu/counselored/">Counselor Education Department</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/soc-summer/rec-797.html">Course Numbering System</a></li>
			<li>> <a href="http://www.science.sjsu.edu/transfer/f10/handouts/Ed_Planner.xls">Course Planner (blank)</a></li>
			<li>> <a href="http://transfer.sjsu.edu/">Courses that tranfer from CA Community Colleges to SJSU</a></li>
			<li>> <a href="http://www.sjsu.edu/webservices/services/websitebuilder/">Creating Faculty web pages</a></li>
			<li>> <a href="http://www.sjsu.edu/ugs/students/specialmajors/Guidelines/">Create your own major</a></li>
			<li>> <a href="http://artic.sjsu.edu/static/catalog/cbe.html">Credit (for course) by Exam Petition</a></li>
			<li>> <a href="http://www.sjsu.edu/ugs/docs/petitions/Foreign_credit.pdf">Credit for International or other university course work not granted</a></li>
			<li>> <a href="http://info.sjsu.edu/static/catalog/grades.html">Credit / No Credit grades (CR/NC)</a></li>
			<li>> <a href="http://artic.sjsu.edu/static/catalog/cbe.html">Credit for Courses by Examination</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/veterans/">Credit for Military Training</a></li>
			<li>> <a href="http://www.usecu.org/home/abo.abo_cu">Credit Union  (USE credit union)</a></li>
			<li>> <a href="https://www.sccfcu.org/asp/home.asp">Credit Union  (Santa Clara county)</a></li>
			<li>> <a href="http://local.yahoo.com/CA/San+Jose/Legal+Financial+Services/Credit+Unions;_ylc=X3oDMTFtM3J0aHV1BF9TAzk3NjcyMDI1BF9zAzk2NjEzNzY3BHNlYwNMZWdhbCAmIEZpbmFuY2lhbCBTZXJ2aWNlcw--">Credit Unions in San Jose Area and near SJSU</a></li>
			<li>> <a href="http://sa.sjsu.edu/counseling/personal_counseling/crisis_intervention.html">Crisis Intervention (SJSU)</a></li>
			<li>> <a href="http://sa.sjsu.edu/mosaic/index.jsp">Cross cultural center</a></li>
			<li>> <a href="http://www.csumentor.edu/">CSU Admissions Application</a></li>
			<li>> <a href="http://as.sjsu.edu/asgsc/index.jsp?val=gsc_services&text=StudentHealthInsurance">CSU Health Link</a></li>
			<li>> <a href="http://www.csumentor.edu/">CSU Mentor</a></li>
			<li>> <a href="http://sa.sjsu.edu/mosaic/index.jsp">Cultural center</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="d" class="title">D</div>
	<div class="text">
		<ul>
			<li>> <a href="http://www.sjsu.edu/about_sjsu/facts_and_figures/">Data about SJSU (general)</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/calendar/">Dates and Deadlines</a></li>
			<li>> <a href="http://as.sjsu.edu/ascdc/index.jsp?val=ascdc_admin_fees">Day Care</a></li>
			<li>> <a href="http://as.sjsu.edu/ascdc/index.jsp">Day Care services</a></li>
			<li>> <a href="http://www.sjsu.edu/parking/pages/motorist2.html">Dead Car Battery</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/catalog/degrees/all-degrees.html">Degrees, List of</a></li>
			<li>> <a href="http://www.sjsu.edu/studenthealth/clinical_services/">Dermatology exam &amp; treatments</a></li>
			<li>> <a href="http://www.m-w.com/">Dictionary Online</a></li>
			<li>> <a href="http://www.sjsu.edu/studenthealth/health_education/">Diet and Nutrition Information</a></li>
			<li>> <a href="https://sjsuone.sjsu.edu/sjsuphonebook/">Directory</a></li>
			<li>> <a href="http://www.spartanshops.com/dining/portal/">Dining Services</a></li>
			<li>> <a href="http://www.drc.sjsu.edu/">Disability Resource Center</a></li>
			<li>> <a href="http://sa.sjsu.edu/ombudsman/index.html">Disputes (assistance with handling)</a></li>
			<li>> <a href="http://sa.sjsu.edu/ombudsman/index.html">Disputes between students &amp; faculty</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/catalog/scholastic.html">Disqualification and Probation</a></li>
			<li>> <a href="http://www.math.sjsu.edu/~mcclory/EO%20665%20Handbook%202K8.doc">Disqualification because of failure to remediate</a></li>
			<li>> <a href="http://www.sjsu.edu/ugs/docs/petitions/Disregard.pdf">Disregard Previous Semesters' Work</a></li>
			<li>> <a href="http://online.sjsu.edu/">Distance Education</a></li>
			<li>> <a href="files/downloads/ge_checklist.xls">Do it yourself GE check list (excel)</a></li>
			<li>> <a href="files/downloads/ge_checklist.pdf">Do it yourself GE check list (PDF)</a></li>
			<li>> <a href="http://www.mapquest.com">Driving directions to almost anywhere (Map quest tool)</a></li>
			<li>> <a href="http://my.sjsu.edu/students/help/QR_SR_SS_Drop_Class/index.htm">Drop a Class, How to</a></li>
			<li>> <a href="http://www.sjsu.edu/includes/calendars/academic/1011aycalendar.pdf">Drop Deadline</a></li>
			<li>> <a href="http://my.sjsu.edu/students/help/QR_SR_SS_Drop_Class/index.htm">Dropping Courses</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="e" class="title">E</div>
	<div class="text">
		<ul>
			<li>> <a href="http://online.sjsu.edu/">E-Campus</a></li>
			<li>> <a href="http://www.vta.org/ecopass/ecopass_corp/index.html">Eco Pass</a></li>
			<li>> <a href="http://www.sjsu.edu/economics/">Economics Department</a></li>
			<li>> <a href="http://www.science.sjsu.edu/transfer/f10/handouts/Ed_Planner.xls">Ed Plan (blank)</a></li>
			<li>> <a href="http://www1.coe.sjsu.edu/">Education, College of</a></li>
			<li>> <a href="http://www.sjsu.edu/edleadership/index.shtml">Educational Leadership Department</a></li>
			<li>> <a href="http://www.sjsu.edu/eop/">Educational Opportunity Program (EOP)</a></li>
			<li>> <a href="https://testing.sjsu.edu/teptelm.html">English Placement Test (EPT)</a></li>
			<li>> <a href="http://www.science.sjsu.edu/transfer/f10/handouts/Ed_Planner.xls">Educational Planner (blank)</a></li>
			<li>> <a href="http://www.engr.sjsu.edu/electrical/">Electrical Engineering Dept.</a></li>
			<li>> <a href="http://www.sjsu.edu/elementaryed/">Elementary Education Department</a></li>
			<li>> <a href="https://testing.sjsu.edu/teptelm.html">ELM/EPT information</a></li>
			<li>> <a href="https://testing.sjsu.edu/teptelminfo.html">ELM/EPT placement and exemption information</a></li>
			<li>> <a href="http://www.sjsu.edu/helpdesk/support/email_support/">E-mail Issues and Problems</a></li>
			<li>> <a href="http://www.sjsu.edu/bursar/services/loans/emergency/">Emergency Loans</a></li>
			<li>> <a href="http://www.sjsu.edu/bursar/forms/">Emergency Loan Application</a></li>
			<li>> <a href="http://www.sjsu.edu/emergency/">Emergency Procedures (Evacuation, etc &hellip;)</a></li>
			<li>> <a href="http://www.engr.sjsu.edu/">Engineering, College of</a></li>
			<li>> <a href="http://www.sjsu.edu/english/">English and Comparative Literature Dept.</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/tutorials/view_appt.pdf">Enrollment Appointments (How to view)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/soc-fall/registration.html">Enrollment Options</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/services/students/unit_load.htm">Enrollment Status (part-time/full-time status)</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/services/verification/">Enrollment Verification</a></li>
			<li>> <a href="https://testing.sjsu.edu/teptelm.html">Entry Level Mathematics (ELM)</a></li>
			<li>> <a href="http://www.sjsu.edu/depts/EnvStudies/">Environmental Studies Dept.</a></li>
			<li>> <a href="http://www.math.sjsu.edu/~mcclory/EO%20665%20Handbook%202K9.doc">EO 665</a></li>
			<li>> <a href="http://www.math.sjsu.edu/~mcclory/EO%20665%20-%20ELM-EPT.doc">EO 665 (Extention for Students admitted by exception)</a></li>
			<li>> <a href="http://www.math.sjsu.edu/~Mcclory/EO%20665%20Handbook%202K9.doc">EO 665 (Reinstatement rules)</a></li>
			<li>> <a href="http://www.sjsu.edu/eop/">EOP (Educational Opportunity Program)</a></li>
			<li>> <a href="http://sa.sjsu.edu/mosaic/index.jsp">Ethnic/Cultural resource center</a></li>
			<li>> <a href="http://www.union.sjsu.edu/ec/ec.html">Event Center</a></li>
			<li>> <a href="http://www.union.sjsu.edu/ec/EC_Box_Office/ec_box_office.html">Event Center box office</a></li>
			<li>> <a href="http://www.union.sjsu.edu/ec/EC_Sport_Club/ec_sport_club.html#maincontent">Excercise on campus</a></li>
			<li>> <a href="http://www.sjsu.edu/advising/faq/index.htm#maxunits">Excess Unit Petition</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="f" class="title">F</div>
	<div class="text">
		<ul>
			<li>> <a href="http://www.sjsu.edu/facultyaffairs/">Faculty Affairs</a></li>
			<li>> <a href="http://www.sjhousing.org/program/sjsu.html">Faculty and staff Homebuyer program</a></li>
			<li>> <a href="https://sjsuone.sjsu.edu/sjsuphonebook/">Faculty Names and Phone Numbers</a></li>
			<li>> <a href="https://sjsuone.sjsu.edu/sjsuphonebook/Offices.aspx">Faculty, Staff &amp; Department directory</a></li>
			<li>> <a href="http://www.sjsu.edu/webservices/services/websitebuilder/">Faculty web pages (Spartan Wizard)</a></li>
			<li>> <a href="http://www.sjsu.edu/people/">Faculty web pages, looking for?</a></li>
			<li>> <a href="http://www.sjsu.edu/faculty/">Faculty web sites</a></li>
			<li>> <a href="http://www.sjsu.edu/about_sjsu/facts_and_figures/">Facts and Figures about SJSU</a></li>
			<li>> <a href="http://www.fafsa.ed.gov/">FAFSA (Free Application for Federal Student Aid)</a></li>
			<li>> <a href="http://sa.sjsu.edu/sll/fall_welcome/index.html">Fall Welcome Days</a></li>
			<li>> <a href="http://www.sjsu.edu/faso/">FASO (Financial Aid and Scholarship Office)</a></li>
			<li>> <a href="http://sa.sjsu.edu/ombudsman/index.html">Feel like you've been treated unfairly?</a></li>
			<li>> <a href="http://www.sjsu.edu/bursar/fees/">Fees</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/catalog/ferpa.html">FERPA (Family Educational Rights and Privacy Act)</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/docs/grad_app.pdf">Filing for Graduation</a></li>
			<li>> <a href="http://www.sjsu.edu/senate/S06-4.htm">Final Exam Policy</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/soc-spring/finals.html">Final Exam Schedule</a></li>
			<li>> <a href="http://www.sjsu.edu/faso/">Financial Aid and Scholarship Office (FASO)</a></li>
			<li>> <a href="http://www.sjsu.edu/people/">Finding Faculty web pages</a></li>
			<li>> <a href="http://www.sjsu.edu/ugs/students/firstyear/">First Year Experience courses and programs for Freshmen</a></li>
			<li>> <a href="http://www.science.sjsu.edu/transfer/">First Year Experience courses and programs for Transfers</a></li>
			<li>> <a href="http://www.sjsu.edu/foreignlanguages/">Foreign Languages Department</a></li>
			<li>> <a href="http://ou.sjsu.edu/required-tests-and-placement/foreign-language-placement-exams">Foreign Language Placement Exam</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/veterans/va_forms/">Forms &amp; Applications for Veteran's (various)</a></li>
			<li>> <a href="http://www.science.sjsu.edu/transfer/f10/handouts/Ed_Planner.xls">Four Semester/Year Plan</a></li>
			<li>> <a href="http://www.fafsa.ed.gov/">Free Application for Federal Student Aid (FAFSA)</a></li>
			<li>> <a href="http://www.sjsu.edu/getinvolved/orientation/new/frosh/">Freshmen Orientation</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/forms/index.htm">Forms and Petitions</a></li>
			<li>> <a href="http://sa.sjsu.edu/sll/fasl/index.html">Fraternity &amp; Sorority life information</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="g" class="title">G</div>
	<div class="text">
		<ul>
			<li>> <a href="http://www.sjsu.edu/aars/">GE Advising (General Education)</a></li>
			<li>> <a href="files/downloads/ge_checklist.xls">GE checklist tool, blank (excel)</a></li>
			<li>> <a href="files/downloads/ge_checklist.pdf">GE checklist tool, blank (PDF)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/soc-fall/ge.html">GE Courses (General Education)</a></li>
			<li>> <a href="http://info.sjsu.edu/home/schedules.html">GE Courses (current) look under &#147;course listings&#148; pdf</a></li>
			<li>> <a href="http://artic.sjsu.edu/web-dbgen/artic/all-ge.html">GE Courses that transfer as GE from Community College</a></li>
			<li>> <a href="http://www.sjsu.edu/ugs/students/petitions/list/index.html#GE%20and%20Grad">GE petitions</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/catalog/rec-2113.html">GE Requirements</a></li>
			<li>> <a href="http://www.sjsu.edu/aars/">General Education Advising</a></li>
			<li>> <a href="http://info.sjsu.edu/cgi-bin/pdfserv?atok=soc">GE From 2005 forward (look under "narrative" sem and yr)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/catalog/rec-2113.html">General Education Requirements</a></li>
			<li>> <a href="http://www.engr.sjsu.edu/gen/">General Engineering Dept.</a></li>
			<li>> <a href="http://www.sjsu.edu/depts/geography/">Geography Dept.</a></li>
			<li>> <a href="http://www.sjsugeology.org/">Geology Dept.</a></li>
			<li>> <a href="http://www.gmac.com/GMAC/">GMAC (Graduate Management Admission Council)</a></li>
			<li>> <a href="http://www.gmac.com/gmac/thegmat/">GMAT (Graduate Management Admission Test)</a></li>
			<li>> <a href="http://www.spartanshops.sjsu.edu/goldpoints/">Gold Points</a></li>
			<li>> <a href="http://www.google.com/">Google</a></li>
			<li>> <a href="http://www.gmail.com/">Google Mail (Gmail)</a></li>
			<li>> <a href="gpa.php">GPA (Grade Point Average) Calculation</a></li>
			<li>> <a href="gpa.php">GPA Calculator</a></li>
			<li>> <a href="http://www.science.sjsu.edu/transfer/f10/handouts/GPA_Calculation.pdf">GPA (Grade Point Average) How to calculate</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/services/GPA_Verification/">GPA (Grade Point Average) Verification</a></li>
			<li>> <a href="files/grade_check1.xls">Grade Checks</a></li>
			<li>> <a href="http://www.science.sjsu.edu/transfer/f10/handouts/GPA_Calculation.pdf">Grade point average</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/tutorials/grade_values.html">Grades and symbols</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/tutorials/grade_values.html">Grades (values including &#43;&#47;&#45;)</a></li>
			<li>> <a href="http://www.sjsu.edu/gradstudies/">Grad. School Admissions (SJSU)</a></li>
			<li>> <a href="http://www.sjsu.edu/gradstudies/Prospective/Graduate_Programs.html">Grad. School program choices at SJSU</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/tutorials/grade_values.html">Grades, Symbols and Values</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/soc-summer/rec-798.html">Grading System</a></li>
			<li>> <a href="http://www.gmac.com/gmac/">Graduate Management Admission Counsil (GMAC)</a></li>
			<li>> <a href="http://www.gmac.com/gmac/thegmat/">Graduate Management Admission Test (GMAT)</a></li>
			<li>> <a href="http://www.sjsu.edu/gradstudies/Prospective/Graduate_Programs.html">Graduate Programs offered at SJSU</a></li>
			<li>> <a href="http://www.ets.org/portal/site/ets/menuitem.fab2360b1645a1de9b3a0779f1751509/?vgnextoid=b195e3b5f64f4010VgnVCM10000022f95190RCRD">Graduate Record Exam (GRE)</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/docs/grad_app.pdf">Graduation Application</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/docs/grad_app.pdf">Graduation, Applying for</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/docs/grad_change.pdf">Graduation date change form</a></li>
			<li>> <a href="http://www.science.sjsu.edu/transfer/f10/handouts/Ed_Planner.xls">Graduation Plan</a></li>
			<li>> <a href="http://www.science.sjsu.edu/transfer/f10/handouts/BS_Grad.pdf">Graduation Requirements (Undergrad)</a></li>
			<li>> <a href="http://www.sjsu.edu/gradstudies/">Graduate Studies Dept. (SJSU)</a></li>
			<li>> <a href="http://www.sjsu.edu/faso/Types_AID/Grant/index.htm">Grant money for paying for college</a></li>
			<li>> <a href="http://sa.sjsu.edu/sll/fasl/index.html">Greek Life at SJSU information</a></li>
			<li>> <a href="http://www.union.sjsu.edu/ec/EC_Sport_Club/ec_sport_club.html#maincontent">Gym, on campus</a></li>
			<li>> <a href="http://www.sjsu.edu/studenthealth/clinical_services/">Gynecological exams</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="h" class="title">H</div>
	<div class="text">
		<ul>
			<li>> <a href="http://sa.sjsu.edu/student_health/index.jsp">Health Center</a></li>
			<li>> <a href="http://as.sjsu.edu/asgsc/index.jsp?val=gsc_services&text=Student%20Medical%20Insurance">Health (Medical) Insurance for students</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/catalog/rec-2035.html">Health Leave</a></li>
			<li>> <a href="http://as.sjsu.edu/asgsc/index.jsp?val=gsc_services&text=StudentHealthInsurance">Health Link (CSU)</a></li>
			<li>> <a href="http://www.sjsu.edu/casa/healthprofessions/">Health Professions Dept.</a></li>
			<li>> <a href="http://www.sjsu.edu/healthscience/">Health Science Dept.</a></li>
			<li>> <a href="http://www.sjsu.edu/depts/history/">History Dept.</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/soc-fall/ge.html">History/Political Science graduation requirements (F1-2-3)</a></li>
			<li>> <a href="http://www.sjsu.edu/studenthealth/clinical_services/">HIV/AIDs (info, testing &amp; counseling)</a></li>
			<li>> <a href="http://www.sjsu.edu/honors/">Honors Programs and Designations</a></li>
			<li>> <a href="http://www.sjsu.edu/hrtm/">Hospitality, Recreation &amp; Tourism Management Dept.</a></li>
			<li>> <a href="http://www.hotmail.com/">Hotmail</a></li>
			<li>> <a href="http://housing.sjsu.edu/">Housing</a></li>
			<li>> <a href="http://housing.sjsu.edu/pros_pricing.html">Housing Rates/Pricing</a></li>
			<li>> <a href="http://housing.sjsu.edu/pros_community.html">Housing Themed communities and programs</a></li>
			<li>> <a href="http://weather.yahoo.com/forecast/USCA0993.html">How hot of cold is it today (San Jose)</a></li>
			<li>> <a href="http://careercenter.sjsu.edu/students/explore/tutorial/exploring_majors.html">How to Choose a Major</a></li>
			<li>> <a href="images/guide.png">How to get to the Science 2 cubicles</a></li>
			<li>> <a href="images/guide.png">How to get to the Science 90t cubicles</a></li>
			<li>> <a href="http://www.sjsu.edu/advising/">HUB, Advising</a></li>
			<li>> <a href="http://www.sjsu.edu/humanities/">Humanities and the Arts, College of</a></li>
			<li>> <a href="http://www.sjsu.edu/hum/">Humanities Dept.</a></li>
			<li>> <a href="http://www.sjsu.edu/hum/honors/">Humanity Honors Program and GE - What counts for what</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="i" class="title">I</div>
	<div class="text">
		<ul>
			<li>> <a href="http://info.sjsu.edu/static/admission/impaction.html">Impaction Information</a></li>
			<li>> <a href="http://www.sjsu.edu/bursar/beginhere/faq/towercardfaqs/towercardfaqs2/index.html">ID Cards</a></li>
			<li>> <a href="http://info.sjsu.edu/static/admission/impaction.html">Impaction Information</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/docs/incomplete_ext.pdf">Incomplete (I) Extension Request</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/soc-summer/rec-796.html">Incomplete (I) Grade(s)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/soc-summer/rec-797.html">Incomplete Charged (IC) Failing to complete Incomplete</a></li>
			<li>> <a href="http://as.sjsu.edu/asgsc/index.jsp?val=gsc_services&text=Student%20Medical%20Insurance">Insurance for students (medical)</a></li>
			<li>> <a href="http://info.sjsu.edu/static/admission/international.html">International Students</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/admission/rec-1701.html">International Student Cost/Fees</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/catalog/ib.html">IB (International Baccalaureate) What counts for what &hellip;</a></li>
			<li>> <a href="http://www.engr.sjsu.edu/ise/">Industrial and Systems Engineering Dept.</a></li>
			<li>> <a href="http://www.sjsu.edu/ihouse/index.htm">International House (Multicultural Student Residence)</a></li>
			<li>> <a href="http://www.sjsu.edu/depts/ipss/">International Programs &amp; Services</a></li>
			<li>> <a href="http://www.sjsu.edu/depts/ipss/">International Students (Admitted)</a></li>
			<li>> <a href="http://info.sjsu.edu/static/admission/international.html">International Students (Prospective)</a></li>
			<li>> <a href="http://careercenter.sjsu.edu/students/experience/internships/internships.html">Internships &amp; Jobs (SJSU Career Center)</a></li>
			<li>> <a href="http://www.sjsu.edu/mediaservices/">IRC (Media Services)</a></li>
			<li>> <a href="http://www.sjsu.edu/helpdesk/support/hours/index.htm">IT support for Faculty &amp; Staff in person</a></li>
			<li>> <a href="http://www.sjsu.edu/helpdesk/">IT support for Faculty &amp; Staff online assistance</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="j" class="title">J</div>
	<div class="text">
		<ul>
			<li>> <a href="http://careercenter.sjsu.edu/events_calendar/events_calendar.html#EmployerConnections">Job Fairs on campus</a></li>
			<li>> <a href="http://careercenter.sjsu.edu/students/launch/job_search/job_search.html">Jobs and Internships (Career Center SJSU)</a></li>
			<li>> <a href="http://careercenter.sjsu.edu/index.html">Jobs (where to find one)</a></li>
			<li>> <a href="http://jmcweb.sjsu.edu/index.html">Journalism and Mass Communications Dept.</a></li>
			<li>> <a href="http://www.sjsu.edu/justicestudies/">Justice Studies Dept.</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="k" class="title">K</div>
	<div id="" class="text">
		<ul>
			<li>> <a href="http://www.sjsu.edu/kinesiology/">Kinesiology Dept.</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="l" class="title">L</div>
	<div class="text">
		<ul>
			<li>> <a href="http://www.sjlibrary.org/services/computers/equipment.htm">Laptop borrow/check-out</a></li>
			<li>> <a href="http://as.sjsu.edu/ascsc/index.jsp?val=csc_lrp">Laptop rental</a></li>
			<li>> <a href="http://www.cs.sjsu.edu/">Laptop rental (CS majors - Scroll to the very bottom)</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/docs/Late_Enroll_Req.pdf">Late Add Petition</a></li>
			<li>> <a href="http://slisweb.sjsu.edu/enrollment/lateadd.htm">Late Add Polices</a></li>
			<li>> <a href="http://www.sjsu.edu/aars/docs/Petition-Drop.pdf">Late Drop Petition</a></li>
			<li>> <a href="http://www.sjsu.edu/aars/policies/latedrops/">Late Drop Polices</a></li>
			<li>> <a href="http://www.lsat.com/AboutLSAC/about-lsac.asp">Law School Admission Counsel (LSAC)</a></li>
			<li>> <a href="http://www.lsat.com/LSAT/about-the-lsat.asp">Law School Admission Test (LSAT)</a></li>
			<li>> <a href="http://www.calstate.edu/acadaff/ldtp/">LDTP (Lower Division Transfer Pattern)</a></li>
			<li>> <a href="http://www.sjsu.edu/larc/">Learning Assistance Resource Center (LARC)</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/docs/leave_request.pdf">Leave of Absence and Withdrawal</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/catalog/rec-2189.html">Leave of Absence (one semester)</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/docs/leave_request.pdf">Leave of Absence request form</a></li>
			<li>> <a href="http://www.sjlibrary.org/">Library</a></li>
			<li>> <a href="http://slisweb.sjsu.edu/">Library and Information Science Dept.</a></li>
			<li>> <a href="http://www.vta.org/schedules/schedules_bynumber.html#100">Light Rail Schedule</a></li>
			<li>> <a href="http://www.sjsu.edu/linguistics/">Linguistics and Language Development</a></li>
			<li>> <a href="http://www.sjsu.edu/aars/policies/remediation/">LLD (advancing through remedial courses)</a></li>
			<li>> <a href="communitycolleges.php">Local Community College information</a></li>
			<li>> <a href="http://www.sjsu.edu/parking/pages/motorist2.html">Locked Keys in Car</a></li>
			<li>> <a href="http://www.sjsu.edu/people/">Looking for Faculty web pages</a></li>
			<li>> <a href="http://www.lsat.com/">LSAC (Law School Admission Counsel )</a></li>
			<li>> <a href="http://www.lsat.com/">LSAT (Law School Admission Test)</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="m" class="title">M</div>
	<div class="text">
		<ul>
			<li>> <a href="http://www.sjsu.edu/gradstudies/Prospective/Graduate_Programs.html">MA Programs (SJSU)</a></li>
			<li>> <a href="http://www.mapquest.com">Map Quest</a></li>
			<li>> <a href="http://artic.sjsu.edu/web-dbgen/artic/all-school-to-school.html">Major Courses that transfer from Community College</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/catalog/departments/all-departments.html">Major Departments</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/catalog/degrees/all-degrees.html">Majors and degrees</a></li>
			<li>> <a href="http://careercenter.sjsu.edu/students/explore/tutorial/exploring_majors.html">Majors, How to choose one</a></li>
			<li>> <a href="http://www.cob.sjsu.edu/mis/">Management Information Systems Dept.</a></li>
			<li>> <a href="http://www.sjsu.edu/about_sjsu/docs/SJSU_campus_map.pdf">Map (SJSU Campus)</a></li>
			<li>> <a href="http://www.cob.sjsu.edu/mkt/">Marketing and Decision Sciences Dept.</a></li>
			<li>> <a href="http://www.sjsu.edu/gape/graduate_programs/">Masters degree programs at SJSU</a></li>
			<li>> <a href="http://www.math.sjsu.edu/">Mathematics Dept.</a></li>
			<li>> <a href="http://www.math.sjsu.edu/~hsu/colloq/">Mathematics Dept. Events</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/catalog/ap.html">Math AP test and scores (tests and scores that equal college credit)</a></li>
			<li>> <a href="http://www.sjsu.edu/math/">Math Education Dept.</a></li>
			<li>> <a href="http://www.engr.sjsu.edu/students/essc/ll/mep">Mathematics Engineering Science Achievement (MESA) program</a></li>
			<li>> <a href="http://www.math.sjsu.edu/~calculus/">Math Placement Exam (MPE)</a></li>
			<li>> <a href="http://www.math.sjsu.edu/~calculus/perishables/mpe_sched.htm">Math Placement Exam (MPE) Schedule</a></li>
			<li>> <a href="http://mcnair.sjsu.edu/">McNair Scholars Program</a></li>
			<li>> <a href="http://housing.sjsu.edu/Student%20Rates/rates/MealsRRP.pdf">Meal Plans</a></li>
			<li>> <a href="http://www.engr.sjsu.edu/mae/">Mechanical and Aerospace Engineering Dept.</a></li>
			<li>> <a href="http://www.sjsu.edu/mediaservices/">Media Services (IRC)</a></li>
			<li>> <a href="http://www.aamc.org/students/mcat/start.htm">Medical College Admission Test (MCAT)</a></li>
			<li>> <a href="http://as.sjsu.edu/asgsc/index.jsp?val=gsc_services&text=Student%20Medical%20Insurance">Medical Insurance (for students)</a></li>
			<li>> <a href="http://sa.sjsu.edu/student_health/index.jsp">Medical Services</a></li>
			<li>> <a href="http://www.sjsu.edu/studenthealth/clinical_services/pharmacy/index.htm">Medication</a></li>
			<li>> <a href="http://www.engr.sjsu.edu/students/progs/mep">MEP (MESA Engineering Program)</a></li>
			<li>> <a href="http://www.engr.sjsu.edu/students/essc/ll/mep">MESA (Mathematics Engineering Science Achievement) program</a></li>
			<li>> <a href="http://www.met.sjsu.edu/">Meteorology Dept.</a></li>
			<li>> <a href="http://www.sjsu.edu/muse/">Metropolitan University Scholar's Experience (MUSE)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/catalog/departments/MAS.html">Mexican American Studies Department</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/catalog/rec-2037.html">Military Leave</a></li>
			<li>> <a href="http://www.sjsu.edu/depts/AFROTC/homepage.html">Military Science (Army ROTC)</a></li>
			<li>> <a href="http://www.engr.sjsu.edu/students/progs/mep">MESA Engineering Program (MEP)</a></li>
			<li>> <a href="http://www.sjsu.edu/faso/">Money for College</a></li>
			<li>> <a href="http://sa.sjsu.edu/mosaic/index.jsp">MOSAIC</a></li>
			<li>> <a href="http://www.mlml.calstate.edu/">Moss Landing Marine Labs</a></li>
			<li>> <a href="http://www.sjsu.edu/parking/pages/motorist2.html">Motorist Assistance</a></li>
			<li>> <a href="http://www.sjsu.edu/ihouse/index.htm">Multicultural Student Residence (International House)</a></li>
			<li>> <a href="http://www.sjsu.edu/muse/">MUSE (Metropolitan University Scholar's Experience)</a></li>
			<li>> <a href="http://www.sjsu.edu/muse/peermentor/">MUSE Peer Mentors</a></li>
			<li>> <a href="http://www.music.sjsu.edu/">Music and Dance Dept.</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/soc-spring/rec-646.html">Music Placement Exam</a></li>
			<li>> <a href="http://my.sjsu.edu/">MySJSU</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="n" class="title">N</div>
	<div class="text">
		<ul>
			<li>> <a href="https://sjsuone.sjsu.edu/sjsuphonebook/">Names and Phone numbers (faculty and staff)</a></li>
			<li>> <a href="http://www.sjsu.edu/parking/pages/motorist2.html">Need a jumpstart for your car?</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/catalog/nondiscrimination.html">Nondiscrimination Policies</a></li>
			<li>> <a href="http://www.sjsu.edu/nursing/">Nursing Dept.</a></li>
			<li>> <a href="http://www.sjsu.edu/studenthealth/health_education/">Nutrition and Diet information</a></li>
			<li>> <a href="http://www.nufs.sjsu.edu/">Nutrition, Food Science, and Packaging Department</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="o" class="title">O</div>
	<div class="text">
		<ul>
			<li>> <a href="http://www.sjsu.edu/occupationaltherapy/">Occupational Therapy Dept.</a></li>
			<li>> <a href="http://www.science.sjsu.edu/transfer/f10/handouts/Office_Info.ppt">Offices and Locations</a></li>
			<li>> <a href="http://www.sjsu.edu/president/">Office of the President</a></li>
			<li>> <a href="http://sa.sjsu.edu/ombudsman/index.html">Ombusman</a></li>
			<li>> <a href="http://www.union.sjsu.edu/Aquatic_Center/aquatic_center.html">On campus swimming lessons</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/catalog/rec-2189.html">One Semester Leave</a></li>
			<li>> <a href="http://www.math.sjsu.edu/~mcclory/EO%20665%20Handbook%202K8.doc">One Year Rule, The</a></li>
			<li>> <a href="http://www.collegesource.org/">Online Catalog source for U.S. Colleges &amp; Universities</a></li>
			<li>> <a href="http://www.sjsu.edu/ecampus/courses/">Online Course Offerings</a></li>
			<li>> <a href="http://ies.sjsu.edu/ou/">Open University</a></li>
			<li>> <a href="https://cmshr.sjsu.edu/psp/HSJPRDF/EMPLOYEE/HSJPRD/c/CSU_SQA.CSU_SQA.GBL?FolderPath=PORTAL_ROOT_OBJECT.CSU_SA_BASELINE.CSU_SA_STUDENT_RECORDS.CSU_SA_QUICK_ADMIT.CSU_SA_SQA_USE.CSU_SQA_GBL">Open University Registration</a></li>
			<li>> <a href="http://www.cob.sjsu.edu/org&mgt/index.htm">Organization and Management Dept.</a></li>
			<li>> <a href="http://sa.sjsu.edu/sll/orientation/frosh/index.html">Orientation - Freshmen</a></li>
			<li>> <a href="http://www.science.sjsu.edu/transfer/">Orientation course for Transfers</a></li>
			<li>> <a href="http://www.sjsu.edu/aars/transfer_orientation/">Orientation-Transfer Information Program</a></li>
			<li>> <a href="http://www.collegesource.org/">Other University Catalogs (Online)</a></li>
			<li>> <a href="http://www.sjsu.edu/soar/">Outreach</a></li>
			<li>> <a href="http://sa.sjsu.edu/counseling/educational_counseling/Over_60_program.html">Over 60 Fee Waiver Program</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="p" class="title">P</div>
	<div class="text">
		<ul>
			<li>> <a href="http://www.sjsu.edu/studenthealth/clinical_services/women_health/index.htm">PAP smear</a></li>
			<li>> <a href="http://www.sjsu.edu/parking/pages/maps2.html">Parking Areas</a></li>
			<li>> <a href="http://www.sjsu.edu/parking/pages/studentinfo.html">Parking Permits</a></li>
			<li>> <a href="https://sjsu.t2hosted.com/cmn/index.aspx?ck=t">Parking Permits (Purchasing)</a></li>
			<li>> <a href="http://www.sjsu.edu/parking/">Parking Services</a></li>
			<li>> <a href="http://www.sjsu.edu/helpdesk/support/hours/index.htm">Password resets (Lotus Notes, MySJSU, Unix, SJSUOne) in person</a></li>
			<li>> <a href="http://www.sjsu.edu/helpdesk/support/passwords/">Password resets (Lotus Notes, MySJSU, Unix, SJSUOne) online assistance</a></li>
			<li>> <a href="http://www.sjsu.edu/faso/">Paying for College</a></li>
			<li>> <a href="http://artic.sjsu.edu/static/catalog/cbe.html">Payment Plans for Reg fees</a></li>
			<li>> <a href="http://artic.sjsu.edu/web-dbgen/narr/catalog/rec-1933.html">PEP (Proficiency Exam Program) What counts for what &hellip;</a></li>
			<li>> <a href="http://sa.sjsu.edu/counseling/personal_counseling/index.html">Personal Counseling (SJSU)</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/forms/index.htm">Petitions and forms</a></li>
			<li>> <a href="http://www.sjsu.edu/ugs/students/petitions/list/">Petitions, List of</a></li>
			<li>> <a href="http://www.sjsu.edu/ugs/docs/petitions/Intensive_Science.pdf">Petition to keep Science classes for GE after changing out of Science major</a></li>
			<li>> <a href="http://www.sjsu.edu/studenthealth/clinical_services/pharmacy/index.htm">Pharmacy</a></li>
			<li>> <a href="http://www.sjsu.edu/philosophy/">Philosophy Dept.</a></li>
			<li>> <a href="https://sjsuone.sjsu.edu/sjsuphonebook/Default.aspx">Phone numbers for faculty, staff &amp; departments</a></li>
			<li>> <a href="http://www.physics.sjsu.edu/">Physics &amp; Astronomy Dept.</a></li>
			<li>> <a href="http://www.physics.sjsu.edu/index.php?q=event">Physics &amp; Astronomy Dept. Events</a></li>
			<li>> <a href="http://www.sjsu.edu/studenthealth/clinical_services/">Physical Exams</a></li>
			<li>> <a href="http://www.sjsu.edu/studenthealth/clinical_services/physical_therapy/index.htm">Physical Therapy</a></li>
			<li>> <a href="http://info.sjsu.edu/static/catalog/integrity.html">Plagiarism</a></li>
			<li>> <a href="http://tutorials.sjlibrary.org/tutorial/plagiarism/index.htm">Plagiarism tutorial</a></li>
			<li>> <a href="http://www.science.sjsu.edu/transfer/f10/handouts/Ed_Planner.xls">Plan Sheet</a></li>
			<li>> <a href="http://www.sjsupd.com/">Police Dept. (SJSU UPD)</a></li>
			<li>> <a href="http://www.sjsu.edu/academic_programs/policies_and_procedures/">Policies and Procedures</a></li>
			<li>> <a href="http://www.sjsu.edu/polisci/">Political Science Dept.</a></li>
			<li>> <a href="http://www.spartanbookstore.com/SiteText.aspx?id=1284">Post Office (on campus)</a></li>
			<li>> <a href="http://www.math.sjsu.edu/~calculus/">Precalculus and Calculus</a></li>
			<li>> <a href="http://www.sjsu.edu/president/">President's Office</a></li>
			<li>> <a href="http://as.sjsu.edu/asps/index.jsp">Printing Services(Associated Students)</a></li>
			<li>> <a href="http://as.sjsu.edu/asps/">Print Shop (on campus)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/catalog/scholastic.html">Probation and Disqualification</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/catalog/rec-2010.html">Probation and Disqualification (academic standards)</a></li>
			<li>> <a href="http://www.spartanshops.sjsu.edu/promotions/">Promotions and Deals (Spartan Shops)</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/services/verification/">Proof of Degree</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/services/verification/">Proof of Enrollment</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/services/GPA_Verification/">Proof of GPA</a></li>
			<li>> <a href="http://www.sjsu.edu/provost/">Provost Office</a></li>
			<li>> <a href="http://sa.sjsu.edu/counseling/psychiatric_services/index.html">Psychiatric Services (counseling services center)</a></li>
			<li>> <a href="http://www.sjsu.edu/studenthealth/clinical_services/">Psychiatry sessions, health center (30-60 min.)</a></li>
			<li>> <a href="http://www.sjsu.edu/psych/">Psychology Dept.</a></li>
			<li>> <a href="http://www.sjsu.edu/publicaffairs/">Public Affairs</a></li>
			<li>> <a href="http://www.sjsupd.com/">Public Safety</a></li>
			<li>> <a href="http://as.sjsu.edu/asts/">Public Transportation</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="r" class="title">R</div>
	<div class="text">
		<ul>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/catalog/rec-2115.html">Re-Admission</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/catalog/rec-2119.html">Re-Admission After disqualification</a></li>
			<li>> <a href="http://as.sjsu.edu/ashouse/index.jsp?val=bbqandrecreation">Recreation Area</a></li>
			<li>> <a href="http://as.sjsu.edu/ascr/index.jsp">Recreation on Campus</a></li>
			<li>> <a href="http://www.sjsu.edu/visit/">Recruitment (SJSU)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/catalog/rec-2029.html">Refunds of Registration fees</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/">Registrar's Office</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/">Registrar web page</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/calendar/">Registration Calendar</a></li>
			<li>> <a href="http://www.sjsu.edu/bursar/fees/regfees/">Registration Fees</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/catalog/rec-2122.html">Registration instructions, policies &amp; procedure</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/">Registration Office</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/soc-fall/rec-301.html">Registration priority (who registers 1st, 2nd, 3rd &hellip;)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/catalog/rec-2117.html">Reinstatement after DQ (disqualification)</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/docs/reinstatement_petition.pdf">Reinstatement Petition</a></li>
			<li>> <a href="http://info.sjsu.edu/static/admission/remediation.html">Remediation</a></li>
			<li>> <a href="http://www.sjsu.edu/sac/policies/remediation/policy/">Remediation Policy (Advancing through LLD and Math)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/admission/rec-1785.html">Remediation (exceptions to the rule)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/admission/rec-1706.html">Remediation (Reinstatement rules)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/admission/remediation.html">Remediation (rules and polices)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/admission/rec-1787.html">Remediation (Special Admits time limit 4 semesters)</a></li>
			<li>> <a href="http://www.sjsu.edu/sac/policies/remediation/policy/">Remediation policies at SJSU for freshmen EO665</a></li>
			<li>> <a href="http://ou.sjsu.edu/academic-information/academic-renewal">Repeating Courses</a></li>
			<li>> <a href="http://www.sjsu.edu/depts/AFROTC/homepage.html">Reserve Officer Training Corps (ROTC)</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/services/Residency/">Residency: Issues and Concerns</a></li>
			<li>> <a href="http://www.sjsu.edu/ugs/docs/petitions/Retro._Acad._Ren.pdf">Retroactive Academic Renewal petition</a></li>
			<li>> <a href="http://www.sjsu.edu/ugs/docs/petitions/Retro._Course_Add.pdf">Retroactive Course Add petition</a></li>
			<li>> <a href="http://www.sjsu.edu/ugs/docs/petitions/Retro._Course_Drop.pdf">Retroactive Course Drop petition</a></li>
			<li>> <a href="http://www.sjsu.edu/ugs/docs/petitions/Retro._Withdrawal.pdf">Retroactive Withdrawl petition</a></li>
			<li>> <a href="http://www.sjsu.edu/depts/AFROTC/homepage.html">ROTC (Air Force)</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="s" class="title">S</div>
	<div class="text">
		<ul>
			<li>> <a href="http://www.sjsupd.com/asr/index.html">Safety Report (Annual)</a></li>
			<li>> <a href="http://www.sjsu.edu/events/">San Jose State Events</a></li>
			<li>> <a href="http://www.sjsu.edu/">San Jose State University</a></li>
			<li>> <a href="http://info.sjsu.edu/home/schedules.html">Schedule of Classes</a></li>
			<li>> <a href="http://www.sjsu.edu/faso/Scholarships/">Scholarships</a></li>
			<li>> <a href="http://www.science.sjsu.edu/">Science, College of</a></li>
			<li>> <a href="images/guide.png">Science 2 cubicle location</a></li>
			<li>> <a href="images/guide.png">Science 90t cubicle location</a></li>
			<li>> <a href="http://www.science.sjsu.edu/scied/">Science Education</a></li>
			<li>> <a href="http://www.mastep.sjsu.edu/serc/Default.htm">Science Education Resource Center</a></li>
			<li>> <a href="https://cmshr.sjsu.edu/psp/HSJPRDF/EMPLOYEE/HSJPRD/c/COMMUNITY_ACCESS.CLASS_SEARCH.GBL?FolderPath=PORTAL_ROOT_OBJECT.PA_HC_CLASS_SEARCH">Searching for classes</a></li>
			<li>> <a href="http://www.sjsu.edu/secondaryed/">Secondary Education Department</a></li>
			<li>> <a href="http://www.sjsu.edu/ccll/">Service Learning (Community Learning & Leadership)</a></li>
			<li>> <a href="http://www.sjsu.edu/webservices/services/faculty/">Services for Faculty (electronic services)</a></li>
			<li>> <a href="http://www.union.sjsu.edu/ec/ec.html">SJSU Event Center</a></li>
			<li>> <a href="http://www.sjsu.edu/events/">SJSU Events</a></li>
			<li>> <a href="http://www.sjsu.edu/gradstudies/">SJSU Grad. School Admissions</a></li>
			<li>> <a href="http://www.csumentor.edu/admissionapp/grad_apply.asp">SJSU Graduate Application</a></li>
			<li>> <a href="http://www.sjsu.edu/gradstudies/Prospective/Graduate_Programs.html">SJSU Graduate Programs</a></li>
			<li>> <a href="http://www.sjsu.edu/gradstudies/">SJSU Graduate Studies</a></li>
			<li>> <a href="http://info.sjsu.edu/static/admission/impaction.html">SJSU Impaction Information</a></li>
			<li>> <a href="http://www.sjsu.edu/sjsuone/about/">SJSUOne</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/soc-fall/sjstudies.html">SJSU Studies (Formerly Advance GE)</a></li>
			<li>> <a href="http://www.csumentor.edu/AdmissionApp/undergrad_apply.asp">SJSU Undergrad Application</a></li>
			<li>> <a href="http://www.sjsu.edu/socialsciences/">Social Science, College of</a></li>
			<li>> <a href="http://www.sjsu.edu/depts/socs/">Social Science Dept.</a></li>
			<li>> <a href="http://www.sjsu.edu/socialwork/">Social Work Dept.</a></li>
			<li>> <a href="http://www.sjsu.edu/sociology/">Sociology Department</a></li>
			<li>> <a href="http://www.bs.se.sjsu.edu/">Software Engineering BS</a></li>
			<li>> <a href="http://sa.sjsu.edu/sll/fasl/index.html">Sorority & Fraternity life information</a></li>
			<li>> <a href="http://www.spartanbookstore.com/">Spartan Bookstore</a></li>
			<li>> <a href="http://www.spartanbookstore.com/SiteText.aspx?id=1284">Spartan Bookstore Post Office</a></li>
			<li>> <a href="http://www.spartanshops.com/bookstore/Insite/Computer_site/index.html">Spartan Computer Store</a></li>
			<li>> <a href="http://www.thespartandaily.com/contact/">Spartan Daily (contact info.)</a></li>
			<li>> <a href="http://www.thespartandaily.com/">Spartan Daily (online paper)</a></li>
			<li>> <a href="http://www.sjsu.edu/webservices/services/websitebuilder/">Spartan Faculty Web Wizard</a></li>
			<li>> <a href="http://www.spartanshops.sjsu.edu/">Spartan Shops</a></li>
			<li>> <a href="http://www.sjsu.edu/specialed/">Special Education Dept.</a></li>
			<li>> <a href="http://www.union.sjsu.edu/ec/EC_Sport_Club/ec_sport_club.html">Sport Club Fitness Center</a></li>
			<li>> <a href="http://www.sjsu.edu/ugs/students/specialmajors/Guidelines/">Special Major</a></li>
			<li>> <a href="http://www.sjhousing.org/program/sjsu.html">Staff &amp; Faculty homebuyer program</a></li>
			<li>> <a href="https://sjsuone.sjsu.edu/sjsuphonebook/Default.aspx">Staff, Faculty &amp; Department Directory</a></li>
			<li>> <a href="https://sjsuone.sjsu.edu/sjsuphonebook/">Staff names and Phone numbers</a></li>
			<li>> <a href="http://www.apb.sjsu.edu/Data_&_Reporting/Statistical_Abstract.cfm">Statistical Abstract</a></li>
			<li>> <a href="http://www.sjsu.edu/about_sjsu/facts_and_figures/index.htm">Statistics Campus Facts and Figures</a></li>
			<li>> <a href="http://www.sjsu.edu/soar/">Step to College</a></li>
			<li>> <a href="http://info.sjsu.edu/home/admission.html">Student Admissions</a></li>
			<li>> <a href="http://studentorgs.sjsu.edu/">Student Clubs and Organizations</a></li>
			<li>> <a href="http://www.sa.sjsu.edu/download/judicial_affairs/Student_Conduct_Code.pdf">Student Code of Conduct</a></li>
			<li>> <a href="http://sa.sjsu.edu/ombudsman/">Student Fairness Committee</a></li>
			<li>> <a href="http://as.sjsu.edu/asgov/">Student Government</a></li>
			<li>> <a href="http://www.sjsu.edu/bursar/services/towercard/">Student ID (Tower Card)</a></li>
			<li>> <a href="http://sa.sjsu.edu/sll/home.jsp">Student Involvement</a></li>
			<li>> <a href="http://as.sjsu.edu/asgsc/index.jsp?val=gsc_services&text=Student%20Medical%20Insurance">Student Medical Insurance</a></li>
			<li>> <a href="http://www.sjsu.netclubmgr.com">Student Organizations</a></li>
			<li>> <a href="http://sa.sjsu.edu/sll/soal/code_of_conduct.pdf">Student Organizations Code of Conduct</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/catalog/ferpa.html">Student Privacy Rights (FERPA)</a></li>
			<li>> <a href="http://www.union.sjsu.edu/">Student Union</a></li>
			<li>> <a href="http://www.sjsu.edu/studyabroad/">Study Abroad</a></li>
			<li>> <a href="http://www.science.sjsu.edu/transfer/">Success as Transfers (Sci 90t)</a></li>
			<li>> <a href="http://www.union.sjsu.edu/Aquatic_Center/aquatic_center.html">Swim lessons (on campus)</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/tutorials/grade_values.html">Symbols and Grades</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="t"class="title">T</div>
	<div class="text">
		<ul>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/catalog/rec-2189.html">Take a Semester off</a></li>
			<li>> <a href="http://www.sjsu.edu/socialsciences/teacherspreparation/index.htm">Teacher preparation program</a></li>
			<li>> <a href="http://www.sjsu.edu/helpdesk/">Technology Help</a></li>
			<li>> <a href="http://www.tvradiofilmtheatre.com/">Television, Radio, Film and Theatre Department</a></li>
			<li>> <a href="http://www.sjsu.edu/linguistics/programs/tesol/index.htm">TESOL (Teaching English to Speakers of Other Languages)</a></li>
			<li>> <a href="https://testing.sjsu.edu/">Testing</a></li>
			<li>> <a href="http://artic.sjsu.edu/static/catalog/cbe.html">Testing out of a course</a></li>
			<li>> <a href="http://www.robertsbookstore.com/buy_main.asp?mscssid=02H3J96LG08J8PLDBLSMH8TKRF1F35K6"> Textbook Finder (local)</a></li>
			<li>> <a href="http://www.spartanbookstore.com/selecttermdept.aspx/">Textbook Finder (on campus)</a></li>
			<li>> <a href="http://www.math.sjsu.edu/~mcclory/EO%20665%20Handbook%202K8.doc">The One Year Rule</a></li>
			<li>> <a href="http://www.science.sjsu.edu/transfer/files/downloads/time_management.xls">Time Management Toolkit (excel)</a></li>
			<li>> <a href="http://www.sjsu.edu/aars/tip/">TIP (Transfer Information Program)</a></li>
			<li>> <a href="http://weather.yahoo.com/forecast/USCA0993.html">Today's Weather (San Jose)</a></li>
			<li>> <a href="http://www.sjsu.edu/bursar/beginhere/faq/towercardfaqs/towercardfaqs2/index.html">Tower Cards</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/services/transcripts/">Transcript (How to request)</a></li>
			<li>> <a href="http://www.assist.org/web-assist/welcome.html">Transferable courses (using ASSIST)</a></li>
			<li>> <a href="http://artic.sjsu.edu/web-dbgen/artic/all-course-to-course.html">Transfer from Community College (Classes from CC to SJSU)</a></li>
			<li>> <a href="http://artic.sjsu.edu/web-dbgen/artic/all-ge.html">Transfer from Community College (GE classes from CC to SJSU)</a></li>
			<li>> <a href="http://artic.sjsu.edu/web-dbgen/artic/all-school-to-school.html">Transfer from Community College (Major classes  from CC to SJSU)</a></li>
			<li>> <a href="http://www.sjsu.edu/aars/tip/">Transfer Information Program (TIP)</a></li>
			<li>> <a href="http://transfer.sjsu.edu/web-dbgen/artic/tpg/templates.html">Transfer Planning</a></li>
			<li>> <a href="http://transfer.sjsu.edu/">Transfer Students - New Student Info &amp; Resources</a></li>
			<li>> <a href="http://as.sjsu.edu/asts/">Transportation Solutions (Bus, Bike, Train)</a></li>
			<li>> <a href="http://www.sjsu.edu/larc/">Tutoring Center</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="u" class="title">U</div>
	<div class="text">
		<ul>
			<li>> <a href="http://www.sjsu.edu/ugs/">Undergraduate Studies</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/services/students/ab540.html">Undocumented Students</a></li>
			<li>> <a href="http://www.sjsu.edu/visit/steptocollegeunitrack/">UniTrack (College credit from high school courses)</a></li>
			<li>> <a href="http://www.sjsu.edu/helpdesk/support/hours/index.htm">University Help Desk (technology help) in person</a></li>
			<li>> <a href="http://www.sjsu.edu/helpdesk/">University Help Desk (technology help) online assistance</a></li>
			<li>> <a href="http://www.sjsupd.com/">UPD (University Police Department)</a></li>
			<li>> <a href="http://www.union.sjsu.edu/ec/Event_Center_Arena/event_center_arena.html">Upcoming events and concerts (Event Center)</a></li>
			<li>> <a href="http://info.sjsu.edu/web-dbgen/narr/static/soc-spring/sjstudies.html">Upper GE (SJSU Studies)</a></li>
			<li>> <a href="http://www.sjsu.edu/urbanplanning/">Urban and Regional Planning Department</a></li>
			<li>> <a href="http://www.spartanbookstore.com/SiteText.aspx?id=1284">USPS (on campus)</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="v" class="title">V</div>
	<div class="text">
		<ul>
			<li>> <a href="http://www.sjsu.edu/registrar/veterans/va_forms/">VA forms</a></li>
			<li>> <a href="http://www.vta.org/">Valley Transportation Authority (VTA)</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/services/verification/">Verification of Degree</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/services/verification/">Verifying Enrollment</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/services/GPA_Verification/">Verifying GPA</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/veterans/">Veteran Affairs</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/veterans/va_forms/">Veteran Affairs forms &amp; applications</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/veterans/">Veterans Services</a></li>
			<li>> <a href="http://sjsu.askadmissions.net/sjsu/aeresults.aspx">Virtual Advisor</a></li>
			<li>> <a href="http://www.sjsu.edu/registrar/docs/visitor.pdf">Visitor Program application</a></li>
			<li>> <a href="http://www.sjsu.edu/soar/">Visitor Relations &amp; Admissions Counseling</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="x" class="title">X</div>
	<div class="text">
		<ul>
			<li>> <a href="http://www.sjsu.edu/studenthealth/clinical_services/">X-Ray</a></li>				
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>
<div id="content">
	<div id="y" class="title">Y</div>
	<div class="text">
		<ul>
			<li>> <a href="http://www.yahoo.com/">Yahoo</a></li>
			<li>> <a href="http://mail.yahoo.com/">Yahoo Mail</a></li>
			<li class="back-to-top"><a href="#toc">Back to top</a></li>
		</ul>
	</div>
</div>