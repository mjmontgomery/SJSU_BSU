<div class="top">Upcoming Assignments and Dates</div>
<div class="text">
  <ul>
  	<!--<li class="bold">First Day of Classes</li>-->
    <li class="bold">First Day of Classes</li>
    <li class="link">&gt;Monday, August 25, 2014</li>
    <!--<li class="link">&gt; August 21, 2013</li>
    <li class="bold">Time Management due</li>
    <li class="link">> February 18, 2013</li>
    <li class="bold">Goals and Objectives due</li>
    <li class="link">> Week of February 25, 2013</li>
    <li class="bold">Digital Time Management and Big Wall Calendar due</li>
    <li class="link">> Week of March 4, 2013</li>
    
    <li class="bold">Grade Checks due</li>
    <li class="link">> Week of March 18, 2013</li>
    <li class="bold">Pathways Assignment due</li>
    <li class="link">> TBD by Activity instructor</li>
    <li class="bold">Wall Calendar / Reader payment due</li>
    <li class="link">> Week of March 4, 2013</li>
    <li class="bold">Campus Events (4) due week of</li>
    <li class="link">> October 22, 2013</li>
    <li class="bold">Scavenger Hunt due</li>
    <li class="link">> April 18, 2013</li>
    <li class="bold">Grade Check II due in activity</li>
    <li class="link">> Week of April 29, 2013</li>
    <li class="bold">Pathways Assignment due</li>
    <li class="link">> TBD by Activity instructor</li>
    -->
  </ul>
</div>